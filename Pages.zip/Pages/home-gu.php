<?php 
  session_start();

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Source+Serif+4&display=swap" rel="stylesheet">

    <link rel="shortcut icon" href="../Farming_logo-bg-t (1).png" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="../Styles\navbar.css">
    <link rel="stylesheet" href="../Styles\home.css">
    <link rel="stylesheet" href="../Styles\footer.css">

    <link rel="stylesheet" href="path/to/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <title>Knowing About Farming</title>
  </head>
  <body>
    <?php include_once 'navbanavbar.php'; ?>
    

    <div class="banner">
      <div class="card bg-dark text-white">
        <img src="https://www.ffa.org/wp-content/uploads/2018/08/103215307-compressor.jpg" class="card-img" alt="...">
        <div class="card-img-overlay">
          <h1 class="card-title">ફાર્મ<span class="A"> ઓ</span>ટોમેશન</h1>
          <p class="card-text ">આધુનિક કૃષિમાં ઇનોવેશન પહેલા કરતાં વધુ મહત્વનું છે. સમગ્ર ઉદ્યોગ પુરવઠાના વધતા ખર્ચ, શ્રમની અછત અને પારદર્શિતા અને ટકાઉપણું માટે ઉપભોક્તાની પસંદગીઓમાં ફેરફાર જેવા મોટા પડકારોનો સામનો કરી રહ્યું છે. કૃષિ નિગમો તરફથી એવી માન્યતા વધી રહી છે કે આ પડકારો માટે ઉકેલની જરૂર છે. છેલ્લા 10 વર્ષોમાં, કૃષિ ટેક્નોલોજીમાં રોકાણમાં જંગી વૃદ્ધિ જોવા મળી છે, જેમાં છેલ્લા 5 વર્ષમાં $6.7 બિલિયનનું રોકાણ કરવામાં આવ્યું છે અને માત્ર છેલ્લા વર્ષમાં જ $1.9 બિલિયનનું રોકાણ કરવામાં આવ્યું છે.</p>
          <button type="button" class="btn btn-success">Know More</button>
        </div>
        <!-- Bottom Arrow -->
          <div class="wrapper">
            <a href="#explore"> 
              <div class="arrow">
                <ul>
                  <li></li>
                  <li></li>
                </ul>
              </div>
            </a>
          </div>
      </div>
    </div>

    
    <div class="container  home-main" id="home-main-title">
      <h3 id="explore"><b>Explore</b></h3>
    </div>
    <div class="container home-main">
      <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col">
          <a href="farmersMarket.html">
            <div class="card h-100 bg-dark text-white ">
              <img src="https://img.freepik.com/photos-gratuite/agriculteur-secouant-main-ses-clients_13339-142788.jpg?size=626&ext=jpg" class="card-img img-fluid" alt="...">
              <div class="card-img-overlay">
                <h3 class="card-title">FARMER'S MARKET</h3>
              </div>
            </div>
          </a>
        </div>
        <div class="col">
          <a href="subsidi.html">
            <div class="card  h-100 bg-dark text-white">
              <img src="https://assets.thehansindia.com/h-upload/2021/02/07/1029549-budget.webp" class="card-img img-fluid" alt="...">
              <div class="card-img-overlay text-center">
                <h3 class="card-title">SUBSIDI</h3>
              </div>
            </div>
          </a>
        </div>
        <div class="col">
          <a href="search.html">
            <div class="card h-100 bg-dark text-white">
              <img src="https://www.fundacionmapfre.org/media/premios-ayudas/premios/premios-fundacion-mapfre-innovacion-social/tendencias/agua-tierra-768x520-1.jpg" class="card-img" alt="...">
              <div class="card-img-overlay">
                <h3 class="card-title">SEARCH</h3>
              </div>
            </div>
          </a>
        </div>
        <div class="col">
          <a href="newTech.html">
            <div class="card h-100 bg-dark text-white">
              <img src="https://precisionagricultu.re/wp-content/uploads/2018/09/Modern-farming-620x330.jpg" class="card-img" alt="...">
              <div class="card-img-overlay">
                <h3 class="card-title">NEW TECHNIQUE</h3>
              </div>
            </div>
          </a>       
        </div>
      </div>
    </div>


    <!-- Quote -->
    <section class="py-5">
    <div class="container-fluid quote">
        <div class="row">
            <div class="col-lg-10 mx-auto">

                <!-- CUSTOM BLOCKQUOTE -->
                <blockquote class="blockquote blockquote-custom bg-white p-5 shadow rounded">
                    <div class="blockquote-custom-icon  shadow"><i class="fa fa-quote-left "></i></div>
                    <p class="mb-0 mt-2 font-italic">“The soil is the great connector of lives, the source and destination of all. It is the healer and restorer and resurrector, by which disease passes into health, age into youth, death into life. Without proper care for it we can have no community, because without proper care for it we can have no life.” </p>
                    <footer class="blockquote-footer pt-4 mt-4 "> Wendell Berry
                    </footer>
                </blockquote><!-- END -->

            </div>
        </div>
    </div>
</section>

    <!-- Footer -->
    <?php include_once "./footer.html" ?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>